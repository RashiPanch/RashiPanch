package Snakegame;

import javax.swing.JFrame;


import java.awt.Color;

public class Game {

	public static void main(String[] args){
		JFrame f = new JFrame("Snake Game");
		f.setBounds(10,10,905,700);
		f.setResizable(false);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		GamePanel panel = new GamePanel();
		panel.setBackground(Color.DARK_GRAY);
		f.add(panel);
		
		f.setVisible(true);
	}

}
