package com.hotel.reservation;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Scanner;

public class Hotelreservation {


	private static final String url = "jdbc:mysql://localhost:3306/tabledashboard";

	private static final String username = "root";

	private static final String pass = "root";

	public static void main(String[] args) throws ClassNotFoundException ,InterruptedException,SQLException{
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		System.out.println("Drivers loaded successfully!");
	}
	catch(ClassNotFoundException e)
	{
		System.out.println(e.getMessage());
	}
	
		
		
			try {
			
			Connection con = DriverManager.getConnection(url, username, pass);
			System.out.println("Connection established");

			while (true) {
				System.out.println();
				System.out.println("HOTEL MANAGEMENT SYSTEM");
				Scanner scanner = new Scanner(System.in);
				System.out.println("1. RESERVE A ROOM");
				
				System.out.println("2. VIEW RESERVATION");
				
				System.out.println("3. GET ROOM NUMBER");
				
				System.out.println("4. UPDATE RESERVATION");
				
				System.out.println("5. DELETE RESERVATION");
				
				System.out.println("0. EXIT");

				System.out.print("Choose an option:-");
				int choice = scanner.nextInt();
				switch (choice) {
				case 1:
					ReserveRoom(con, scanner);
					break;
				case 2:
					ViewReservation(con);
					break;
				case 3:
					GetRoomNumber(con, scanner);
					break;
				case 4:
					UpdateReservation(con, scanner);
					break;
				case 5:
					DeleteReservation(con, scanner);
					break;
				case 0:
					exit();
					scanner.close();
					return;
				default:
					System.out.println("invalid choice.try again!");

				}

			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
			catch(InterruptedException e)
			{
				throw new RuntimeException(e);
			}
		System.out.println("connection established successfully");
	}

	private static void ReserveRoom(Connection con, Scanner scanner) {

		try {
			System.out.println("Enter Name:");
			String name = scanner.next();
			scanner.nextLine();
			System.out.println("Enter room no");
			int room = scanner.nextInt();
			System.out.println("Enter contact no");
			long contact = scanner.nextLong();

			String sql = "INSERT INTO hotel(name,room,contact)" + "values('" + name + "' , " + room
					+  " ," + contact +" )";

			try (Statement statement = con.createStatement()) {
				int rows = statement.executeUpdate(sql);

				if (rows > 0) {
					System.out.println("Inserted successfully");

				} else {
					System.out.println("Failed to insert!");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void ViewReservation(Connection con) {

		String sql = "SELECT * FROM hotel where id = ? ";

		try (Statement statement = con.createStatement(); 
				ResultSet rs = statement.executeQuery(sql)) {
			System.out.println(" Current reservation:");
			System.out.println("---------------+----------------+-----------------+------------------+-------------");
			System.out.println("Reservation ID | Guest Name     | Room No          |  Contact No      | Date       ");
			System.out.println("---------------+----------------+-----------------+------------------+-------------");
			
			while (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				int room = rs.getInt(3);
				long contact = rs.getLong(4);
				String date = rs.getTimestamp(5).toString();
				
				
			}
			System.out.println("-----------------------------------------------------------------------------------------------");
			
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	private static void GetRoomNumber(Connection con, Scanner scanner) {

		try {
			System.out.println("Enter id:");
			int id = scanner.nextInt();
			System.out.println("Enter  name :");
			String name = scanner.next();

			String sql = "Select * room from hotel \n " + " where id = " + id + "name =" + name + "'";

			try (Statement statement = con.createStatement();
					ResultSet rs = statement.executeQuery(sql)) {
				if (rs.next()) {
					int room = rs.getInt(id);
					System.out.println("Room no for reservation id is" + id + " name  is" + name + "is : " + room);
				} else {
					System.out.println("Reservation is not found for the given id ");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void UpdateReservation(Connection con, Scanner scanner) {

		try {
		System.out.println("Enter id to update:");
		int id = scanner.nextInt();
		scanner.nextLine();

		if (!reservationExists(con, id)) {
			System.out.println("Reservation not found for the given id");
			return;
		}
		
		System.out.println("Enter new guest Name :");
		String name = scanner.nextLine();
		System.out.println("Enter new room number");
		int room = scanner.nextInt();
		System.out.print("Enter a new contact number");
		long contact = scanner.nextLong();
		

		String sql = "Update hotel Set "+ " new guest name '" + name  +  "'new room number " +   room +   "new contact number "+ contact  + " where id = " +  id;

		try {
			Statement statement = con.createStatement();
			int rows = statement.executeUpdate(sql);

			if (rows > 0) {
				System.out.println("Reservation updated successfully");
			} else {
				System.out.println("Reservation updated failed");
			
		}
		
			
		
		
	

		} catch (SQLException e) {

			e.printStackTrace();
		


}

	private static boolean reservationExists(Connection con, int id) {

		try {
			String sql = "Select id from hotel where id = " + id;

			try (Statement statement = con.createStatement(); 
					ResultSet rs = statement.executeQuery(sql)) {
				return rs.next();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

	private static void DeleteReservation(Connection con, Scanner scanner) {

		try {
			System.out.println("Enter reservation Id to delete:");
			int id = scanner.nextInt();

			if (!reservationExists(con, id)) {
				System.out.println("Reservation is not found for the given id ");
				return;
			}

			String sql = "DELETE from hotel where  id =" + id;
			try (Statement statement = con.createStatement()) {
				int rows = statement.executeUpdate(sql);
				if (rows > 0) {
					System.out.println("Reservation deleted successfully!");
				} else {
					System.out.println("Reservation deletion failed");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void exit() throws InterruptedException {
		int i = 5;
		while (i != 0) {
			System.out.print(".");
			Thread.sleep(100);
			i--;
		}
		System.out.println();
		System.out.println("Thank you for using Hotel reservation system!!!");

	}

}
