package com.hospital;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class HospitalManagementSystem {

	private static final String url = "jdbc:mysql://localhost:3306/tabledashboard";
	
	private static final String username = "root";
	
	private static final String password = "root";
	
	public static void main(String[] args) {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		Scanner scanner = new Scanner(System.in);

		try {
			Connection connection = DriverManager.getConnection(url, username, password);

			Patient patient = new Patient(connection, scanner);
			Doctor doctor = new Doctor(connection, scanner);
			while (true) {
				System.out.println("HOSPITAL MANAGEMENT SYSTEM");
				System.out.println("1. Add patient");
				System.out.println("2. View patient");
				System.out.println("3. View doctors");
				System.out.println("4. Book appointment");
				System.out.println("5. Exit");
				System.out.println("Enter your choice: ");

				int choice = scanner.nextInt();

				switch (choice) {
				case 1:
					patient.addPatient();
					System.out.println();
				case 2:
					patient.viewPatient();
					System.out.println();

				case 3:
					doctor.viewDoctor();
					System.out.println();
				case 4:
					bookAppointment(patient, doctor, connection, scanner);
					System.out.println();

				case 5:
					return;
				default:
					System.out.println("Enter valid choice:");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	

 public static void bookAppointment(Patient patient,Doctor doctor,Connection connection, Scanner scanner) {
	
	System.out.print("Enter Patient id:");
	int patient_id = scanner.nextInt();
	System.out.print("Enter Doctor id:");
	int doctor_id = scanner.nextInt();
	System.out.print("Enter BookAppointment date (YYYY-MM-DD) :");
	String appointment_date = scanner.next();
	
	if(patient.getPatientById(patient_id) && doctor.getDoctorById(doctor_id))
	{
		if(checkDoctorAvailability(doctor_id,appointment_date,connection)) {
			String appointment_query = "Insert into appointment(patient,doctor,date) values(?,?,?)";
			try {
				PreparedStatement preparedStatement = connection.prepareStatement(appointment_query);
				preparedStatement.setInt(1,patient_id);
				preparedStatement.setInt(2, doctor_id);
				preparedStatement.setString(3,appointment_date);
				int rowsaffected = preparedStatement.executeUpdate();
				if(rowsaffected>0) {
					System.out.println("Appointment booked!");
				}
				else {
					System.out.println("Failed to book appointment");
				}
				
			
		
				
			}catch(SQLException e) {
				e.printStackTrace();
			}
	}
			else {
				System.out.println("Doctor not available on this date");
			}
 }
		else {
			System.out.println("Either doctor or patient doesn't exist!!!");
		}
	}
 
			
private static boolean checkDoctorAvailability(int doctor_id, String appointment_date,Connection connection) {
	
	String query = "Select count(*) from appointment where doctor_id = ? and appointment_date =?";
	try {
		
		PreparedStatement preparedStatement = connection.prepareStatement(query);
		 preparedStatement.setInt(1, doctor_id);
		 preparedStatement.setString(2, appointment_date);
		 ResultSet resultSet = preparedStatement.executeQuery();
		 while(resultSet.next())
		 {
			 int count =resultSet.getInt(1);
			 if(count==0){
				 return true;
			 }
			 else {
				 return false;
			 }
		 }
	}catch(SQLException e) {
		e.printStackTrace();
	}

	
	return false;
}
}

